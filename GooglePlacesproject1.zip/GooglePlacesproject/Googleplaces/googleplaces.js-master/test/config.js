(function () {
    "use strict";
    
    exports.apiKey = "AIzaSyCyI0p8LFLngM4s9qCu-zVl6P1MAe-e7j4"; 
    	//|| process.env.GOOGLE_PLACES_API_KEY;
    //|| "your google api key (server) comes here";
    exports.outputFormat = "json";
    	//process.env.GOOGLE_PLACES_OUTPUT_FORMAT || "json";

})();
