//Lets require/import the HTTP module
var http = require('http');
var Httpdispatcher = require('httpdispatcher');

var dispatcher = new Httpdispatcher();



//Lets define a port we want to listen to
var PORT=8087; 

//We need a function which handles requests and send response
/*function handleRequest(request, response){
response.end('It Works!! Path Hit: ' + request.url);
}
*/


//Lets use our dispatcher
/*function handleRequest(request, response){
    try {
        //log the request on console
        console.log(request.url);
        //Disptach
        dispatcher.dispatch(request, response);
    } catch(err) {
        console.log(err);
    }
}
*/

//Create a server
var server = http.createServer(handleRequest);

//Lets start our server
server.listen(PORT, function(){
    //Callback triggered when server is successfully listening. Hurray!
    console.log("Server listening on: http://localhost:%s", PORT);
});



//For all your static (js/css/images/etc.) set the directory name (relative path).
dispatcher.setStatic('resources');

/*
app.get('/', function(req, res){
    console.log(req.query.name);
    res.send('Response send to client::'+req.query.name);

});
*/

//A sample GET request    
dispatcher.onGet("/page1", function(req, res) {
    res.writeHead(200, {'Content-Type': 'text/plain'});
    res.end('Page One');
    console.log(req.name);
});    

dispatcher.onGet("/home", function(req, res) {
    res.writeHead(200, {'Content-Type': 'text/plain'});
    res.end('HomePage');
});    

dispatcher.onGet("/", function(req, res) {
    res.writeHead(200, {'Content-Type': 'text/plain'});
    res.end('Index page');
    console.log(req.query.name);
    res.end(req.name);
}); 


//A sample POST request
app.onPost("/post1", function(req, res) {
    res.writeHead(200, {'Content-Type': 'text/plain'});
    res.end('Got Post Data');
    console.log(req.query.name);
});
