#!/bin/sh

#node test/EventsTest.js
node test/GooglePlacesTest.js
node test/ImageFetchTest.js
node test/PlaceAutocompleteTest.js
node test/PlaceDetailsRequestTest.js
node test/PlaceSearchTest.js
node test/RadarSearchTest.js
node test/TextSearchTest.js
node test/PlaceDetailsRequestTest.js


